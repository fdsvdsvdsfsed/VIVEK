module com.example.hehehe {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;
    requires java.sql;

    opens com.example.hehehe to javafx.fxml;
    exports com.example.hehehe;
}